package org.example;

import java.io.IOException;

public class Program {
    public static void main(String[] args) throws IOException {

        Farm farm = new Farm("Jensens FarmVille");
        farm.run();

    }
}


